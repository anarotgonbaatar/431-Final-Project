import { BrowserRouter, Routes, Route } from 'react-router-dom'
import AuthPage from './components/AuthPage'
import ProfilePage from './components/ProfilePage'

function App() {
	return (
		<BrowserRouter>
			<Routes>
				<Route path="/" element={ <AuthPage /> } />
				<Route path="/profile" element={ <ProfilePage /> } />
			</Routes>
		</BrowserRouter>
	)
}

export default App